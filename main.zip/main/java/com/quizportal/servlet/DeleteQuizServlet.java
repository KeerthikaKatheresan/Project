package com.quizportal.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.quizportal.util.DBConnection;

@WebServlet("/DeleteQuizServlet")
public class DeleteQuizServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int quizId = Integer.parseInt(request.getParameter("quizId"));

        try (Connection con = DBConnection.getConnection()) {

        	PreparedStatement ps1 = con.prepareStatement("DELETE FROM attempts WHERE quiz_id=?");
        	ps1.setInt(1, quizId);
        	ps1.executeUpdate();

        	PreparedStatement ps2 = con.prepareStatement("DELETE FROM quiz_questions WHERE quiz_id=?");
        	ps2.setInt(1, quizId);
        	ps2.executeUpdate();

        	PreparedStatement ps3 = con.prepareStatement("DELETE FROM quizzes WHERE quiz_id=?");
        	ps3.setInt(1, quizId);
        	ps3.executeUpdate();

//            PreparedStatement ps = con.prepareStatement(
//                "DELETE FROM quizzes WHERE quiz_id=?");
//            ps.setInt(1, quizId);
//            ps.executeUpdate();

            response.sendRedirect("views/adminDashboard.jsp");

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
