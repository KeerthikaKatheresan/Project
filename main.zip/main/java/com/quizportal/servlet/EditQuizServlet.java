package com.quizportal.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.quizportal.util.DBConnection;

@WebServlet("/EditQuizServlet")
public class EditQuizServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int quizId = Integer.parseInt(request.getParameter("quizId"));

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM quizzes WHERE quiz_id = ?");
            ps.setInt(1, quizId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                request.setAttribute("quizId", rs.getInt("quiz_id"));
                request.setAttribute("quizName", rs.getString("quiz_name"));
                request.setAttribute("description", rs.getString("description"));
                request.setAttribute("totalQuestions", rs.getInt("total_questions"));
            }

            // Forward to editQuiz.jsp
            request.getRequestDispatcher("views/editQuiz.jsp").forward(request, response);

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}

