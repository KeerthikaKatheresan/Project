package com.quizportal.servlet;

import com.quizportal.util.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/UpdateQuizServlet")
public class UpdateQuizServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/views/login.jsp");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");

        int quizId = Integer.parseInt(request.getParameter("quizId"));
        String quizName = request.getParameter("quizName");
        String description = request.getParameter("description");
        String category = request.getParameter("category");

        String[] questionIds = request.getParameterValues("questionId[]");
        String[] questions = request.getParameterValues("questionText[]");
        String[] optionA = request.getParameterValues("optionA[]");
        String[] optionB = request.getParameterValues("optionB[]");
        String[] optionC = request.getParameterValues("optionC[]");
        String[] optionD = request.getParameterValues("optionD[]");
        String[] correctOption = request.getParameterValues("correctOption[]");

        if(questions == null || questions.length == 0) {
            response.getWriter().println("Error: No questions provided.");
            return;
        }

        Connection con = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // transaction

            // Update quiz table
            PreparedStatement psQuiz = con.prepareStatement(
                "UPDATE quizzes SET quiz_name=?, description=?, category=?, total_questions=? WHERE quiz_id=?"
            );
            psQuiz.setString(1, quizName);
            psQuiz.setString(2, description);
            psQuiz.setString(3, category);
            psQuiz.setInt(4, questions.length);
            psQuiz.setInt(5, quizId);
            psQuiz.executeUpdate();
            psQuiz.close();

            // Update each question
            for(int i=0; i<questions.length; i++) {
                int qId = Integer.parseInt(questionIds[i]);

                PreparedStatement psQ = con.prepareStatement(
                    "UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE question_id=?"
                );
                psQ.setString(1, questions[i]);
                psQ.setString(2, optionA[i]);
                psQ.setString(3, optionB[i]);
                psQ.setString(4, optionC[i]);
                psQ.setString(5, optionD[i]);
                psQ.setString(6, correctOption[i]);
                psQ.setInt(7, qId);

                psQ.executeUpdate();
                psQ.close();
            }

            con.commit();
            response.sendRedirect(request.getContextPath() + "/views/adminDashboard.jsp");

        } catch(Exception e) {
            e.printStackTrace();
            try {
                if(con != null) con.rollback();
            } catch(SQLException se) { se.printStackTrace(); }
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try {
                if(con != null) con.setAutoCommit(true);
                if(con != null) con.close();
            } catch(SQLException se) { se.printStackTrace(); }
        }
    }
}
