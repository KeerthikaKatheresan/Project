package com.quizportal.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.quizportal.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/QuizQuestionsServlet")
public class QuizQuestionsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int quizId = Integer.parseInt(request.getParameter("quizId"));

        List<Map<String, Object>> questions = new ArrayList<>();

        try (Connection con = DBConnection.getConnection()) {

            String sql =
                "SELECT q.question_id, q.question_text, q.correct_option " +
                "FROM questions q " +
                "JOIN quiz_questions qq ON q.question_id = qq.question_id " +
                "WHERE qq.quiz_id = ? " +
                "ORDER BY qq.question_order";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, quizId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("id", rs.getInt("question_id"));
                row.put("text", rs.getString("question_text"));
                row.put("correct", rs.getString("correct_option"));
                questions.add(row);
            }

            request.setAttribute("quizId", quizId);
            request.setAttribute("questions", questions);

            request.getRequestDispatcher("views/quizQuestions.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
