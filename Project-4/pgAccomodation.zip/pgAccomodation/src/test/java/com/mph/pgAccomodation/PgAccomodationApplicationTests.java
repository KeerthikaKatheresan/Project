package com.mph.pgAccomodation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgAccomodationApplicationTests {

	@Test
	void contextLoads() {
	}

}
