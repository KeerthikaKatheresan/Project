package com.mph.pgAccomodation.dto;

public class TenantDTO {

}
