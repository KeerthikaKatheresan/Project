package com.mph.pgAccomodation.exception;

public class ResourceNotFoundException {

}
