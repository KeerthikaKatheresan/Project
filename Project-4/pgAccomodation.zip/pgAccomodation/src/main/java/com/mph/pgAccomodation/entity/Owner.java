package com.mph.pgAccomodation.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "owners")
public class Owner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ownerId;

    private String name;
    private int age;
    private String email;
    private String mobile;

    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
    private List<PgPlace> pgPlaces;

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public List<PgPlace> getPgPlaces() {
		return pgPlaces;
	}

	public void setPgPlaces(List<PgPlace> pgPlaces) {
		this.pgPlaces = pgPlaces;
	}

    
}