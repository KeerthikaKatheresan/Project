package com.mph.pgAccomodation.exception;

public class GlobalExceptionHandler {

}
