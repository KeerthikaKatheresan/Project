package com.mph.pgAccomodation.controller;

import com.mph.pgAccomodation.entity.PgPlace;
import com.mph.pgAccomodation.service.PgPlaceService;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/pg")
public class PgPlaceController {

    private final PgPlaceService pgPlaceService;

    public PgPlaceController(PgPlaceService pgPlaceService) {
        this.pgPlaceService = pgPlaceService;
    }

    @PostMapping
    public PgPlace addPg(@RequestBody PgPlace pgPlace) {
        return pgPlaceService.savePgPlace(pgPlace);
    }

    @GetMapping
    public List<PgPlace> getAllPg() {
        return pgPlaceService.getAllPgPlaces();
    }

    @GetMapping("/{id}")
    public PgPlace getPgById(@PathVariable Long id) {
        return pgPlaceService.getPgPlaceById(id);
    }

    @GetMapping("/city/{city}")
    public List<PgPlace> getPgByCity(@PathVariable String city) {
        return pgPlaceService.getPgByCity(city);
    }
}