package com.mph.pgAccomodation.service.impl;

import com.mph.pgAccomodation.entity.PgPlace;
import com.mph.pgAccomodation.repository.PgPlaceRepository;
import com.mph.pgAccomodation.service.PgPlaceService;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PgPlaceServiceImpl implements PgPlaceService {

    private final PgPlaceRepository pgPlaceRepository;

    public PgPlaceServiceImpl(PgPlaceRepository pgPlaceRepository) {
        this.pgPlaceRepository = pgPlaceRepository;
    }

    @Override
    public PgPlace savePgPlace(PgPlace pgPlace) {
        // business logic hook (future-proofing)
        pgPlace.setVisitorCount(0);
        return pgPlaceRepository.save(pgPlace);
    }

    @Override
    public List<PgPlace> getAllPgPlaces() {
        return pgPlaceRepository.findAll();
    }

    @Override
    public PgPlace getPgPlaceById(Long id) {
        return pgPlaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("PG not found"));
    }

    @Override
    public List<PgPlace> getPgByCity(String city) {
        return pgPlaceRepository.findByCity(city);
    }
}