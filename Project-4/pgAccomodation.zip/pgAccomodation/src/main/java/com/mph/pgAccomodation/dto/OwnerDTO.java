package com.mph.pgAccomodation.dto;

public class OwnerDTO {

}
