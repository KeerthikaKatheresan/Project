package com.mph.pgAccomodation.service;

import java.util.List;
import com.mph.pgAccomodation.entity.Tenant;

public interface TenantService {

    Tenant addTenant(Tenant tenant);

    List<Tenant> getAllTenants();

    Tenant getTenantById(Long id);

    void deleteTenant(Long id);
}
