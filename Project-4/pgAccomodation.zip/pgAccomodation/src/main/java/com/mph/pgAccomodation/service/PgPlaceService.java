package com.mph.pgAccomodation.service;

import com.mph.pgAccomodation.entity.PgPlace;
import java.util.List;

public interface PgPlaceService {

    PgPlace savePgPlace(PgPlace pgPlace);

    List<PgPlace> getAllPgPlaces();

    PgPlace getPgPlaceById(Long id);

    List<PgPlace> getPgByCity(String city);
}