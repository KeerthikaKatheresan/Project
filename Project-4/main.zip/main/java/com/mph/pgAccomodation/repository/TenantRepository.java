package com.mph.pgAccomodation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mph.pgAccomodation.entity.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long> {

    // Spring auto-generates queries
    // Example (optional):
    // List<Tenant> findByCity(String city);
}