package com.mph.pgAccomodation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mph.pgAccomodation.entity.Owner;

public interface OwnerRepository extends JpaRepository<Owner, Long> {

}
