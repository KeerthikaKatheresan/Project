package com.mph.pgAccomodation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.mph.pgAccomodation.entity.PgPlace;
import java.util.List;

public interface PgPlaceRepository extends JpaRepository<PgPlace, Long> {

    
	List<PgPlace> findByCityAndAvailabilityTrue(String city);

	List<PgPlace> findByLocalityContainingIgnoreCaseAndAvailabilityTrue(String locality);

}