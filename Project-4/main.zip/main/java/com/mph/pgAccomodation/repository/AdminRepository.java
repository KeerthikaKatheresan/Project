package com.mph.pgAccomodation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mph.pgAccomodation.entity.Admin;


public interface AdminRepository extends JpaRepository<Admin, Long> {
    // Optional: find by username/email if needed
}