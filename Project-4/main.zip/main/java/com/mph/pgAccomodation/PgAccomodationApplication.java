package com.mph.pgAccomodation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgAccomodationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgAccomodationApplication.class, args);
	}

}
