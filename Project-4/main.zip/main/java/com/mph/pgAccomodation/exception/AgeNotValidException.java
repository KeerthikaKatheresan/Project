package com.mph.pgAccomodation.exception;

public class AgeNotValidException extends RuntimeException {

    public AgeNotValidException() {
        super("Age must be 18 or above to register or post a PG place.");
    }

    public AgeNotValidException(String message) {
        super(message);
    }
}