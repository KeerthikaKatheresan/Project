package com.mph.pgAccomodation.service.impl;



import org.springframework.stereotype.Service;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.entity.Tenant;
import com.mph.pgAccomodation.exception.ResourceNotFoundException;
import com.mph.pgAccomodation.repository.OwnerRepository;
import com.mph.pgAccomodation.repository.TenantRepository;
import com.mph.pgAccomodation.service.AdminService;

import org.springframework.beans.factory.annotation.Autowired;



import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private TenantRepository tenantRepository;

    @Autowired
    private OwnerRepository ownerRepository;

    @Override
    public List<Tenant> getAllTenants() {
        return tenantRepository.findAll();
    }

    @Override
    public List<Owner> getAllOwners() {
        return ownerRepository.findAll();
    }

    @Override
    public void deleteTenant(Long tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant", "id", tenantId));
        tenantRepository.delete(tenant);
    }

    @Override
    public void deleteOwner(Long ownerId) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Owner", "id", ownerId));
        ownerRepository.delete(owner);
    }
}

