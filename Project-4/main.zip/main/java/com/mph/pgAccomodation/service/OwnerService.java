package com.mph.pgAccomodation.service;

import java.util.List;
import com.mph.pgAccomodation.entity.Owner;

public interface OwnerService {

    Owner saveOwner(Owner owner);

    List<Owner> getAllOwners();

    Owner getOwnerById(Long ownerId);

    void deleteOwner(Long ownerId);
}