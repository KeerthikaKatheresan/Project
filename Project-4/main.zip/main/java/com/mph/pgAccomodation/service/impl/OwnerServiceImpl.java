package com.mph.pgAccomodation.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.exception.ResourceNotFoundException;
import com.mph.pgAccomodation.repository.OwnerRepository;
import com.mph.pgAccomodation.service.OwnerService;

@Service
public class OwnerServiceImpl implements OwnerService {

    private final OwnerRepository ownerRepository;

    public OwnerServiceImpl(OwnerRepository ownerRepository) {
        this.ownerRepository = ownerRepository;
    }

    @Override
    public Owner saveOwner(Owner owner) {

        // 🚦 PHASE 4 — Age Validation
        if (owner.getAge() < 18) {
            throw new RuntimeException("Owner must be 18 or above");
        }

        return ownerRepository.save(owner);
    }

    @Override
    public List<Owner> getAllOwners() {
        return ownerRepository.findAll();
    }

    @Override
    public Owner getOwnerById(Long ownerId) {
        return ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Owner", "id", ownerId));
    }


    @Override
    public void deleteOwner(Long ownerId) {

        // 🚦 PHASE 4 — Validate before delete
        Owner owner = getOwnerById(ownerId);
        ownerRepository.delete(owner);
    }
}
