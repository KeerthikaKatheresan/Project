package com.mph.pgAccomodation.service;


import java.util.List;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.entity.Tenant;


public interface AdminService {
    List<Tenant> getAllTenants();
    List<Owner> getAllOwners();
    void deleteTenant(Long tenantId);
    void deleteOwner(Long ownerId);
}
