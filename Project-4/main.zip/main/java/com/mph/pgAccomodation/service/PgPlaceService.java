package com.mph.pgAccomodation.service;

import com.mph.pgAccomodation.dto.PgPlaceDTO;
import com.mph.pgAccomodation.entity.PgPlace;
import java.util.List;

public interface PgPlaceService {

	PgPlace savePgPlace(PgPlace pgPlace);

    List<PgPlace> getAllPgPlaces();

    PgPlaceDTO getPgPlaceById(Long id);

    List<PgPlaceDTO> getPgByCity(String city);

    List<PgPlaceDTO> getPgByLocality(String locality);

    PgPlace changeAvailability(Long id, boolean status);
    
    void deletePg(Long id);

}