package com.mph.pgAccomodation.service.impl;

import com.mph.pgAccomodation.dto.OwnerDTO;
import com.mph.pgAccomodation.dto.PgPlaceDTO;
import com.mph.pgAccomodation.entity.PgPlace;
import com.mph.pgAccomodation.exception.ResourceNotFoundException;
import com.mph.pgAccomodation.repository.PgPlaceRepository;
import com.mph.pgAccomodation.service.PgPlaceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PgPlaceServiceImpl implements PgPlaceService {

    private final PgPlaceRepository pgPlaceRepository;

    public PgPlaceServiceImpl(PgPlaceRepository pgPlaceRepository) {
        this.pgPlaceRepository = pgPlaceRepository;
    }

    private PgPlaceDTO mapToDTO(PgPlace pg) {

        PgPlaceDTO dto = new PgPlaceDTO();
        dto.setPgId(pg.getPgId());
        dto.setRegistrationNo(pg.getRegistrationNo());
        dto.setBuiltUpArea(pg.getBuiltUpArea());
        dto.setRent(pg.getRent());
        dto.setCity(pg.getCity());
        dto.setLocality(pg.getLocality());
        dto.setAvailability(pg.isAvailability());
        dto.setVisitorCount(pg.getVisitorCount());

        if (pg.isAvailability()) {
            OwnerDTO ownerDTO = new OwnerDTO();
            ownerDTO.setOwnerId(pg.getOwner().getOwnerId());
            ownerDTO.setName(pg.getOwner().getName());
            ownerDTO.setEmail(pg.getOwner().getEmail());
            ownerDTO.setMobile(pg.getOwner().getMobile());
            dto.setOwner(ownerDTO);
        }

        return dto;
    }

    @Override
    public PgPlace savePgPlace(PgPlace pgPlace) {
        pgPlace.setVisitorCount(0);
        pgPlace.setAvailability(true);
        return pgPlaceRepository.save(pgPlace);
    }

    @Override
    public List<PgPlace> getAllPgPlaces() {
        return pgPlaceRepository.findAll();
    }

    @Override
    public PgPlaceDTO getPgPlaceById(Long id) {

    	PgPlace pg = pgPlaceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PGPlace", "id", id));


        pg.setVisitorCount(pg.getVisitorCount() + 1);
        pgPlaceRepository.save(pg);

        return mapToDTO(pg);
    }


    @Override
    public List<PgPlaceDTO> getPgByCity(String city) {
        return pgPlaceRepository.findByCityAndAvailabilityTrue(city)
                .stream()
                .map(this::mapToDTO)
                .toList();
    }

    @Override
    public List<PgPlaceDTO> getPgByLocality(String locality) {
        return pgPlaceRepository
                .findByLocalityContainingIgnoreCaseAndAvailabilityTrue(locality)
                .stream()
                .map(this::mapToDTO)
                .toList();
    }


    @Override
    public PgPlace changeAvailability(Long id, boolean status) {
        PgPlace pg = pgPlaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("PG not found"));

        pg.setAvailability(status);
        return pgPlaceRepository.save(pg);
    }
    @Override
    public void deletePg(Long id) {
        PgPlace pg = pgPlaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("PG not found"));
        pgPlaceRepository.delete(pg);
    }

}