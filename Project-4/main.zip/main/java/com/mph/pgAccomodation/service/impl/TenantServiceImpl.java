package com.mph.pgAccomodation.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.entity.Tenant;
import com.mph.pgAccomodation.exception.ResourceNotFoundException;
import com.mph.pgAccomodation.repository.TenantRepository;
import com.mph.pgAccomodation.service.TenantService;

@Service
public class TenantServiceImpl implements TenantService {

    @Autowired
    private TenantRepository tenantRepository;

    @Override
    public Tenant addTenant(Tenant tenant) {
        return tenantRepository.save(tenant);
    }

    @Override
    public List<Tenant> getAllTenants() {
        return tenantRepository.findAll();
    }

    @Override
    public Tenant getTenantById(Long id) {
        Tenant t = tenantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant", "id", id));
        return t;
    }


    @Override
    public void deleteTenant(Long id) {
        getTenantById(id); // ensures it exists, throws exception if not
        tenantRepository.deleteById(id); // pass the ID, not the object
    }

}