package com.mph.pgAccomodation.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.entity.Tenant;
import com.mph.pgAccomodation.service.AdminService;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // View all tenants
    @GetMapping("/tenants")
    public List<Tenant> getAllTenants() {
        return adminService.getAllTenants();
    }

    // View all owners
    @GetMapping("/owners")
    public List<Owner> getAllOwners() {
        return adminService.getAllOwners();
    }

    // Delete tenant by ID
    @DeleteMapping("/tenants/{id}")
    public String deleteTenant(@PathVariable Long id) {
        adminService.deleteTenant(id);
        return "Tenant with ID " + id + " deleted successfully.";
    }

    // Delete owner by ID
    @DeleteMapping("/owners/{id}")
    public String deleteOwner(@PathVariable Long id) {
        adminService.deleteOwner(id);
        return "Owner with ID " + id + " deleted successfully.";
    }
}
