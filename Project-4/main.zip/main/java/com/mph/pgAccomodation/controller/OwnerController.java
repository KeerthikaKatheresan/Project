package com.mph.pgAccomodation.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mph.pgAccomodation.entity.Owner;
import com.mph.pgAccomodation.entity.PgPlace;
import com.mph.pgAccomodation.service.OwnerService;
import com.mph.pgAccomodation.service.PgPlaceService;

@RestController
@RequestMapping("/owners")
public class OwnerController {

    private final OwnerService ownerService;

    
    

    private final PgPlaceService pgPlaceService;

    public OwnerController(OwnerService ownerService, PgPlaceService pgPlaceService) {
        this.ownerService = ownerService;
        this.pgPlaceService = pgPlaceService;
    }

    @PostMapping("/places/add/{ownerId}")
    public ResponseEntity<PgPlace> addPg(
            @PathVariable Long ownerId,
            @RequestBody PgPlace pgPlace) {

        Owner owner = ownerService.getOwnerById(ownerId);
        pgPlace.setOwner(owner);

        return new ResponseEntity<>(
                pgPlaceService.savePgPlace(pgPlace),
                HttpStatus.CREATED
        );
    }

    @PatchMapping("/places/{pgId}")
    public PgPlace changeAvailability(
            @PathVariable Long pgId,
            @RequestParam boolean status) {

        return pgPlaceService.changeAvailability(pgId, status);
    }

    // CREATE
    @PostMapping
    public ResponseEntity<Owner> createOwner(@RequestBody Owner owner) {
        return new ResponseEntity<>(ownerService.saveOwner(owner), HttpStatus.CREATED);
    }

    // READ ALL
    @GetMapping
    public List<Owner> getAllOwners() {
        return ownerService.getAllOwners();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Owner getOwnerById(@PathVariable Long id) {
        return ownerService.getOwnerById(id);
    }

    @DeleteMapping("/places/delete/{pgId}")
    public ResponseEntity<String> deletePg(@PathVariable Long pgId) {
        pgPlaceService.deletePg(pgId);
        return ResponseEntity.ok("PG deleted successfully");
    }

}

