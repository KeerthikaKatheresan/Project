package com.mph.pgAccomodation.controller;

import com.mph.pgAccomodation.dto.PgPlaceDTO;
import com.mph.pgAccomodation.entity.PgPlace;
import com.mph.pgAccomodation.service.PgPlaceService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pg")
public class PgPlaceController {

    private final PgPlaceService pgPlaceService;

    public PgPlaceController(PgPlaceService pgPlaceService) {
        this.pgPlaceService = pgPlaceService;
    }

    // 1️⃣ Retrieve available PGs by city (Tenant)
    @GetMapping("/{city}")
    public List<PgPlaceDTO> getPgByCity(@PathVariable String city) {
        return pgPlaceService.getPgByCity(city);
    }

    // 2️⃣ Retrieve PGs by locality (Text search)
    @GetMapping("/locality/{locality}")
    public List<PgPlaceDTO> getPgByLocality(@PathVariable String locality) {
        return pgPlaceService.getPgByLocality(locality);
    }

    // 3️⃣ Retrieve PG details by ID (visitor count++)
    @GetMapping("/details/{id}")
    public PgPlaceDTO getPgDetails(@PathVariable Long id) {
        return pgPlaceService.getPgPlaceById(id);
    }
}
