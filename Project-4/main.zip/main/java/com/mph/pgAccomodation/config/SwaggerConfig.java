package com.mph.pgAccomodation.config;

public class SwaggerConfig {

}
