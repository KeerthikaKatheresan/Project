import { Component, OnInit } from '@angular/core';
import { Plan } from '../../models/plan.model';
import { InsuranceService } from '../../services/insurance';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-plans',
  templateUrl: './plans.html',
  imports: [CommonModule]
})
export class PlansComponent implements OnInit {

  plans: any[] = [];


  constructor(
  private insuranceService: InsuranceService,
  private router: Router
) {}

   ngOnInit(): void {
     this.insuranceService.getAllPlans().subscribe(data => {
      this.plans = data;
      console.log('Plans component loaded');
    });
   }
  selectPlan(planId: number) {
  this.router.navigate(['/payment', planId]);
}
}
