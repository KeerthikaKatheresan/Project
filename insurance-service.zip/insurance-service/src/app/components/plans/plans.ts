
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { InsuranceService } from '../../services/insurance';
import { Plan } from '../../models/plan.model';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './plans.html',
  styleUrls: ['./plans.css']
})
export class PlansComponent implements OnInit {

  showAgePopup = true;  // popup visible on load
  showPlans = false;    // plans hidden until age confirmed

  plans: Plan[] = [];   // plans fetched from db.json

  constructor(
    private insuranceService: InsuranceService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.insuranceService.getAllPlans().subscribe({
      next: (data) => this.plans = data,
      error: (err) => console.error('Error fetching plans:', err)
    });
  }

  ageYes() {
    this.showAgePopup = false;  // hide popup
    this.showPlans = true;      // show plans
  }

  ageNo() {
    this.router.navigate(['/']);  // redirect to home
  }

  selectPlan(planId: number) {
    console.log('Selected Plan ID:', planId);
    // Here you can store the selected plan or navigate to payment page
    this.router.navigate(['/payment', planId]);
  }
}
