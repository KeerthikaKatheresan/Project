import { Component } from '@angular/core';

@Component({
  selector: 'app-premium',
  imports: [],
  templateUrl: './premium.html',
  styleUrl: './premium.css',
})
export class Premium {

}
