import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { UserDetails } from '../../models/user-details.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user-details',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user-details.html',
  styleUrls: ['./user-details.css'],
})
export class UserDetailsComponent {
  user: UserDetails = {
    name: '',
    email: '',
    phone: '',
    city: '',
    age: 0,
    salary: 0,
    healthIssue: false,
  };

  constructor(private userService: UserService, private router: Router) {}

  submitForm() {
    if (!this.user.email.includes('@')) {
      alert('Enter a valid email');
      return;
    }

    if (this.user.age < 30) {
      alert('Age must be 30 or above');
      return;
    }

    this.userService.setUserDetails(this.user);

    this.router.navigate(['/premium']);
  }
}
