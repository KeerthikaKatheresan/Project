import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { InsuranceService } from '../../services/insurance';
import { Plan } from '../../models/plan.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.html',
  styleUrls: ['./payment.css'],
  imports: [CommonModule, FormsModule]
  
})
export class PaymentComponent implements OnInit {

  planId!: number;
  plan!: Plan;

  name: string = '';
  cardNumber: string = '';
  city: string = '';
  age!: number;

  submitted: boolean = false;

  constructor(private route: ActivatedRoute, private insuranceService: InsuranceService, private router: Router) {}

  ngOnInit(): void {
    this.planId = Number(this.route.snapshot.paramMap.get('planId'));

    this.insuranceService.getAllPlans().subscribe((plans: Plan[]) => {
      this.plan = plans.find(p => p.planId === this.planId)!;
    });
  }

  submitPayment() {
    this.submitted = true;

    if (!this.name || !this.cardNumber || !this.city || !this.age || this.age <= 29) {
      alert('Please fill all fields correctly.');
      return;
    }

    if (this.cardNumber.length < 12) {
      alert('Card number must be at least 12 digits.');
      return;
    }

    // Payment successful logic (you can save booking in db.json or navigate)
    //alert(`Payment successful for plan: ${this.plan.planName}`);
    this.router.navigate(['/success']);  // Redirect to success page
  }
}
