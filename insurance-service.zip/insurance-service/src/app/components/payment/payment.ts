import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { InsuranceService } from '../../services/insurance';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './payment.html'
})
export class PaymentComponent implements OnInit {

  planId!: number;
  plan: any;

  // 👇 Declare form fields
  name: string = '';
  cardNumber: string = '';
  city: string = '';
  paymentMode: string = 'credit card'; // default
  age!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,             // 👈 Inject router
    private insuranceService: InsuranceService
  ) {}

  ngOnInit(): void {
    this.planId = Number(this.route.snapshot.paramMap.get('planId'));

    this.insuranceService.getPlanById(this.planId).subscribe(data => {
      this.plan = data[0];
    });
  }

  submitPayment() {
    const booking = {
      planId: this.planId,
      planName: this.plan.planName,
      name: this.name,
      cardNumber: this.cardNumber,
      city: this.city,
      paymentMode: this.paymentMode,
      age: this.age,
      premiumAmt: this.plan.baseAmt,
      paymentFreq: 'yearly',   // you can make this dynamic
      validity: this.plan.validity
    };

    this.insuranceService.bookPlan(booking)
      .subscribe(() => {
        this.router.navigate(['/success']);
      });
  }
}
