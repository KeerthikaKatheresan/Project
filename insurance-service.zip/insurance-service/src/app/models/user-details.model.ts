export interface UserDetails {
  name: string;
  email: string;
  phone: string;
  city: string;
  age: number;
  salary: number;
  healthIssue: boolean;
}
