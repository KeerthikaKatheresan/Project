export interface Booking {
  planId: number;
  cardNumber: string;
  name: string;
  date: string;
}
