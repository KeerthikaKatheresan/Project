import { Routes } from '@angular/router';
import { PlansComponent } from './components/plans/plans';
import { PaymentComponent } from './components/payment/payment';
import { Success } from './components/success/success';
import { AboutComponent } from './components/about/about';
import { HomeComponent } from './components/home/home';

export const routes: Routes = [
  
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
//   { path: 'premium', component: PremiumComponent },
  { path: 'plans', component: PlansComponent },
  { path: 'payment/:planId', component: PaymentComponent },
  { path: 'success', component: Success }
];
