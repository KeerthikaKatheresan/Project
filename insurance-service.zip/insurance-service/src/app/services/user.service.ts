import { Injectable } from '@angular/core';
import { UserDetails } from '../models/user-details.model';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private userDetails!: UserDetails;

  setUserDetails(details: UserDetails) {
    this.userDetails = details;
  }

  getUserDetails(): UserDetails {
    return this.userDetails;
  }

  clearUserDetails() {
    this.userDetails = undefined as any;
  }
}
