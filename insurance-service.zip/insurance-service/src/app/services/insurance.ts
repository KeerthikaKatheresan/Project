import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Plan } from '../models/plan.model';

@Injectable({
  providedIn: 'root'
})
export class InsuranceService {

  private baseUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  // GET all plans
  getAllPlans() {
    return this.http.get<Plan[]>(`${this.baseUrl}/plans`);
  }

  // GET plan by ID
  getPlanById(planId: number) {
    return this.http.get<Plan[]>(`${this.baseUrl}/plans?planId=${planId}`);
  }

  // POST booking
  bookPlan(data: any) {
    return this.http.post(`${this.baseUrl}/bookings`, data);
  }
}
