import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Plan } from '../models/plan.model';

@Injectable({
  providedIn: 'root',
})
export class InsuranceService {
  private baseUrl = 'http://localhost:3000';

   private selectedPlan!: Plan;
  constructor(private http: HttpClient) {}

  // GET all plans
  getAllPlans() {
    return this.http.get<Plan[]>(`${this.baseUrl}/plans`);
  }

  // GET plan by ID
  getPlanById(planId: number) {
    return this.http.get<Plan[]>(`${this.baseUrl}/plans?planId=${planId}`);
  }

  // POST booking
  bookPlan(data: any) {
    return this.http.post(`${this.baseUrl}/bookings`, data);
  }

  getBookingsByEmail(email: string) {
    return this.http.get<any[]>(`${this.baseUrl}/bookings?email=${email}`);
  }

  setSelectedPlan(plan: Plan) {
    this.selectedPlan = plan;
  }

  getSelectedPlan(): Plan {
    return this.selectedPlan;
  }
}
